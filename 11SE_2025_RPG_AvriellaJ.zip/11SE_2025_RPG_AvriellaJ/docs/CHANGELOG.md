# Changelog

All notable changes to this project will be documented in this file.

## [1.2.0] - 2025-08-30
### Fixed
- Fixed color handling in win message display
- Removed duplicate color definitions in game_controller.py
- Improved spacing in win message to prevent overlap with menu
- Standardized color usage across all UI elements
- Fixed potential color code issues in different terminal environments

## [1.1.0] - 2025-08-29
### Fixed
- Droid blocking mechanism in Main Corridor now properly responds to tool usage
- Win condition now only triggers on explicit 'win' command in Docking Bay
- Movement and item pickup sequence flow improvements
- Fixed inventory display to show all carried items
- Resolved issue with droid blocking path after repair

### Added
- Clear instructions for using the diagnostic tool on the droid
- Comprehensive score and hazard tracking system
- Enhanced room descriptions with more immersive details
- Status command to show current score and hazard count
- Improved error messages for invalid commands

## [1.0.0] - 2025-08-28
### Added
- Initial game release with complete core functionality
- Core game mechanics:
  - Room navigation with directional commands (north, south, east, west)
  - Item collection and inventory management
  - Droid repair puzzle using diagnostic tool
  - Energy crystal collection and win condition
  - Hazard system tracking dangerous encounters
- Game world featuring:
  - Maintenance Tunnels (starting area)
  - Engineering Bay with diagnostic tool
  - Main Corridor with droid encounter
  - Docking Bay with energy crystal
  - Additional areas for exploration
- Player character with:
  - Inventory system
  - Score tracking
  - Hazard counter
- Basic ASCII art for locations
- Command parsing system for natural language input
- Help system with available commands
- Game saving/loading functionality
- Basic documentation:
  - README.md with game instructions
  - PRD.md with project requirements
  - CHANGELOG.md for version history

## [0.9.0] - 2025-08-25
### Added
- Initial game structure and architecture
- Basic room navigation system
- Core classes (GameController, Player, Location, Items)
- Basic command parsing
- Initial implementation of game loop

## [0.8.0] - 2025-08-20
### Added
- Project setup and initial file structure
- Basic documentation outline
- Requirements specification
- Initial game design document
