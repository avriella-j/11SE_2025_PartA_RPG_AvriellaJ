"""
Game Controller Module

Handles the main game loop and state management.
"""
import os
import time
import textwrap
from typing import Optional, Dict, List, Tuple, Any, Union, TYPE_CHECKING
# Using a class as a namespace for ANSI color constants
# This follows the Singleton pattern - only one instance needed system-wide
class Colors:
    """ANSI color codes for terminal output.
    
    This class demonstrates the use of class attributes as constants.
    The all-caps naming convention clearly indicates these are constants.
    """
    # Color codes for different UI elements
    HEADER = '\033[95m'  # Used for section headers
    BLUE = '\033[94m'    # Used for water/technical elements
    CYAN = '\033[96m'    # Used for UI borders and highlights
    GREEN = '\033[92m'   # Used for success messages
    YELLOW = '\033[93m'  # Used for warnings and important info
    RED = '\033[91m'     # Used for errors and danger states
    GREY = '\033[90m'    # Used for disabled/de-emphasized text
    
    # Control codes (not colors but related to text formatting)
    ENDC = '\033[0m'     # Reset all formatting
    BOLD = '\033[1m'     # Make text bold

from .game_objects import (
    Location, 
    Player, 
    DamagedMaintenanceDroid
)
from .items import DiagnosticTool, EnergyCrystal

if TYPE_CHECKING:
    from .game_objects import Room

def wrap_text(text: str, width: int = 70) -> str:
    """Wrap text to the specified width, preserving existing newlines.
    
    Args:
        text: The text to wrap
        width: Maximum line width
        
    Returns:
        The wrapped text with preserved paragraphs
    """
    # Split into paragraphs and wrap each one
    paragraphs = text.split('\n')
    wrapped_paragraphs = [textwrap.fill(p, width=width) for p in paragraphs]
    return '\n'.join(wrapped_paragraphs)

class GameController:
    """Controls the main game loop and manages game state.
    
    This is the main controller class that follows the Facade pattern,
    providing a simple interface to the complex game systems.
    It coordinates between different game objects and manages the game flow.
    """
    
    def __init__(self):
        """Initialize the game world and state with dependency injection.
        
        Implements lazy initialization pattern - game objects are created when needed.
        Type hints are used for better IDE support and code documentation.
        """
        # Game world components (Composition relationship)
        self.maintenance_tunnels: Optional[Location] = None
        self.docking_bay: Optional[Location] = None
        
        # Game objects (Aggregation relationship)
        self.droid: Optional[DamagedMaintenanceDroid] = None
        self.player: Optional[Player] = None
        
        # Game items (Composition relationship)
        self.diagnostic_tool: Optional[DiagnosticTool] = None
        self.energy_crystal: Optional[EnergyCrystal] = None
        
        # Game state flag (State pattern could be used here for more complex states)
        self.droid_encounter_active: bool = False
        
    def clear_screen(self):
        """Clear the terminal screen."""
        # Try native clear
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
        except Exception:
            pass
        # ANSI fallback (helps in some IDE terminals)
        try:
            print("\033[2J\033[H", end="", flush=True)
        except Exception:
            pass
        self.last_command: str = ""
    
    def build_world(self):
        """Build the game world with locations, items, and the droid."""
        # Create locations
        maintenance_tunnels = Location("Maintenance Tunnels", 
                                     "You are in the dimly lit maintenance tunnels of the space station. "
                                     "The walls are lined with pipes and conduits. The air is stale. "
                                     "Tunnels branch off to the north, south, and west.")
        
        # Create other locations
        north_tunnel = Location("North Tunnel Junction",
                              "This junction connects to the northern maintenance sectors. "
                              "The lighting here is even dimmer than in the main tunnels, "
                              "with only emergency strips providing illumination. "
                              "The air is colder here, and you can hear distant machinery humming.")
        
        south_storage = Location("South Storage Room",
                               "A cluttered storage room filled with maintenance supplies. "
                               "Shelves line the walls, stocked with spare parts, tools, and equipment. "
                               "The room smells faintly of oil and cleaning supplies.")
        
        west_shaft = Location("West Access Shaft",
                            "A narrow vertical access shaft with a ladder leading up and down. "
                            "Warning signs indicate restricted access to authorized personnel only. "
                            "The metal rungs of the ladder feel cold to the touch.")
        
        # Create Docking Bay with droid
        docking_bay = Location("Docking Bay",
                             "A large open area with several docking ports. "
                             "The main airlock leads to the ship you need to board. "
                             "The room is well-lit but currently empty.")
        
        # Create Main Corridor with droid
        main_corridor = Location("Main Corridor",
                               "A long corridor connecting different sections of the station. "
                               "The lights flicker occasionally, casting eerie shadows. "
                               "The corridor extends to the east and west.\n\n"
                               "A damaged maintenance droid blocks the east exit. "
                               "Use the command 'use tool' to repair the droid and clear the path.")
        main_corridor.set_droid_present(True)
        
        # Set up items
        south_storage.has_tool = True  # Diagnostic tool in storage room
        docking_bay.has_crystal = True  # Energy crystal in docking bay
        
        # Connect locations
        maintenance_tunnels.add_exit("north", north_tunnel)
        maintenance_tunnels.add_exit("south", south_storage)
        maintenance_tunnels.add_exit("west", west_shaft)
        maintenance_tunnels.add_exit("east", main_corridor)
        
        main_corridor.add_exit("west", maintenance_tunnels)
        main_corridor.add_exit("east", docking_bay)
        
        docking_bay.add_exit("west", main_corridor)
        
        # Set starting location and create player
        self.player = Player(maintenance_tunnels)
        self.maintenance_tunnels = maintenance_tunnels
        self.docking_bay = docking_bay
        
        engineering = Location("Engineering Bay",
                             "The engineering bay is filled with control panels and monitoring equipment. "
                             "Warning lights blink on various consoles.")
        
        corridor = Location("Main Corridor",
                          "A long, dimly lit corridor stretches before you. Emergency lighting casts "
                          "an eerie glow on the metal walls. The corridor connects to several "
                          "important areas of the station.")
        
        medbay = Location("Medical Bay",
                        "The medical bay is clean and well-organized. Medical equipment lines the walls, "
                        "and an examination table sits in the center.")
        
        docking_bay = Location("Docking Bay",
                             "The large docking bay is where ships come and go. Currently, it's mostly empty "
                             "except for some cargo containers and a small shuttle.")
        
        # Set up location connections (map to Location objects)
        maintenance_tunnels.exits = {
            "north": north_tunnel,
            "south": south_storage,
            "west": west_shaft,
            "east": engineering,
        }
        
        # Connect new rooms back to maintenance tunnels
        north_tunnel.exits = {
            "south": maintenance_tunnels
        }
        
        south_storage.exits = {
            "north": maintenance_tunnels
        }
        
        west_shaft.exits = {
            "east": maintenance_tunnels
        }
        engineering.exits = {
            "west": maintenance_tunnels,
            "east": corridor,
        }
        # Set up corridor exits
        corridor.exits = {
            "west": engineering,
            "east": docking_bay,  # This will be blocked by the droid
            "south": medbay,
        }
        
        # No droid blocking the path anymore
        medbay.exits = {
            "north": corridor,
        }
        
        # Add blocked exit to docking bay (blocked by droid)
        docking_bay.exits = {
            "west": corridor,
        }
        
        # Set up the droid in the corridor
        corridor.droid_present = True
        corridor.blocked_exit = 'east'  # Block the east exit to Docking Bay
        
        # Add items to locations
        engineering.has_tool = True  # Add tool to Engineering Bay
        docking_bay.has_crystal = True  # Add crystal to Docking Bay
        
        
        # Save references to key locations
        self.maintenance_tunnels = maintenance_tunnels
        self.docking_bay = docking_bay
        
        # Initialize player at starting location
        self.player = Player(maintenance_tunnels)
    
    def process_input(self, command: str) -> str:
        """Process a player command and return the game's response.
        
        Args:
            command: The command entered by the player
            
        Returns:
            str: The game's response to the command
        """
        command = command.lower().strip()
        
        # Handle win command
        if command == 'win':
            if self.player.has_crystal and self.player.current_location == self.docking_bay:
                return self.handle_win()
            else:
                return "You can't win yet. You need to have the energy crystal and be in the Docking Bay."
        
        # Handle movement commands
        if command in ['north', 'south', 'east', 'west', 'n', 's', 'e', 'w']:
            # Convert single-letter directions to full words
            direction_map = {'n': 'north', 's': 'south', 'e': 'east', 'w': 'west'}
            direction = direction_map.get(command, command)
            return self.handle_movement(direction)
            
        # Handle other commands
        elif command in ['pick up tool', 'get tool']:
            return self.handle_pick_up_tool()
            
        elif command in ['use tool', 'use diagnostic tool']:
            return self.handle_use_tool()
            
        elif command in ['pick up crystal', 'get crystal']:
            return self.handle_pick_up_crystal()
            
        elif command in ['status', 'score']:
            return self.player.get_status()
            
        elif command == 'help':
            return self.get_help_text()
            
        elif command in ['quit', 'exit']:
            return "Thanks for playing!"
            
        elif command in ['look', 'look around']:
            return self.get_room_description(self.player.current_location)
            
        elif command == 'inventory' or command == 'i':
            return self.show_inventory()
            
        else:
            return "I don't understand that command. Type 'help' for a list of commands."
    
    def handle_movement(self, direction: str) -> str:
        """Handle player movement in the given direction.
        
        Args:
            direction: The direction to move
            
        Returns:
            str: The result of the movement attempt
        """
        if direction not in self.player.current_location.exits:
            return "You can't go that way."
            
        next_location = self.player.current_location.exits[direction]
        
        # Check for blocked exit in the current location
        current_room = self.player.current_location
        if hasattr(current_room, 'blocked_exit') and direction == current_room.blocked_exit:
            self.player.hazard_count += 1
            return ("A damaged maintenance droid blocks the path to the east! (Hazard +1)\n"
                   "Use the command 'use tool' to repair the droid.\n"
                   f"{self.player.get_status()}")
        
        # Move the player
        self.player.current_location = next_location
        
        # Return the room description
        return f"You move {direction}.\n\n{self.get_room_description(next_location)}"
        
    def handle_pick_up_tool(self) -> str:
        """Handle the 'pick up tool' command.
        
        Returns:
            str: The result of the attempt
        """
        if self.player.pick_up_tool():
            return f"You pick up the diagnostic tool. (+10)\n{self.player.get_status()}"
        return "There is no tool to pick up here."
        
    def handle_use_tool(self) -> str:
        """Handle the 'use tool' command.
        
        Returns:
            str: The result of the attempt
        """
        if not self.player.has_tool:
            return "You don't have a diagnostic tool."
            
        # Check if there's a droid in the current location
        current_room = self.player.current_location
        if hasattr(current_room, 'droid_present') and current_room.droid_present:
            # Repair the droid
            current_room.droid_present = False
            if hasattr(current_room, 'blocked_exit'):
                delattr(current_room, 'blocked_exit')
            self.player.score += 20
            
            # Check if this was the droid blocking the way to Docking Bay
            if current_room.name == 'Main Corridor':
                # Make sure the east exit to Docking Bay is open
                if 'east' in current_room.exits and \
                   current_room.exits['east'].name == 'Docking Bay':
                    return ("You successfully repair the droid! It powers down and moves out of the way. (+20)\n"
                           "The path to the Docking Bay is now clear!\n"
                           f"{self.player.get_status()}")
        
            return f"You successfully repair the droid! (+20)\n{self.player.get_status()}"
        else:
            return "There's no droid here to repair."
        
    def handle_pick_up_crystal(self) -> str:
        """Handle the 'pick up crystal' command.
        
        Returns:
            str: The result of the attempt
        """
        # Check if current location has a crystal and player doesn't already have one
        if hasattr(self.player.current_location, 'has_crystal') and self.player.current_location.has_crystal:
            self.player.current_location.has_crystal = False
            self.player.has_crystal = True
            self.player.score += 50
            return ("You pick up the energy crystal. It pulses with a warm light. (+50)\n"
                   "Type 'win' to complete your mission.\n"
                   f"{self.player.get_status()}")
        return "There is no crystal to pick up here."
        
    def get_help_text(self) -> str:
        """Get the help text with available commands.
        
        Returns:
            str: The help text
        """
        return """Available commands:
- north/south/east/west: Move in that direction
- pick up tool: Pick up a diagnostic tool
- use tool: Use the diagnostic tool on a droid
- pick up crystal: Pick up an energy crystal
- win: Complete the mission (only works in Docking Bay with crystal)
- status: Show your current score and hazards
- help: Show this help text
- quit: Quit the game"""
        
    def check_win_condition(self) -> bool:
        """Check if the player has won the game.
        
        Returns:
            bool: True if the player has won, False otherwise
        """
        return (self.player.has_crystal and 
                self.player.current_location == self.docking_bay)
                
    def handle_win(self) -> str:
        """Handle the win condition and calculate final score.
        
        Returns:
            str: The win message with final score
        """
        # Calculate final score with bonus
        base_score = self.player.score
        hazard_penalty = self.player.hazard_count * 5
        win_bonus = 30
        final_score = base_score - hazard_penalty + win_bonus
        
        # Ensure score doesn't go below 0
        final_score = max(0, final_score)
        
        # Build win message with fancy box
        box_width = 50
        def center_text(text, width=box_width):
            return text.center(width)
            
        message = [
            "\n" + "╔" + "═" * (box_width-2) + "╗",
            "║" + "░▒▓█ MISSION ACCOMPLISHED! █▓▒░".center(box_width-2) + "║",
            "╟" + "─" * (box_width-2) + "╢",
            "║" + " " * (box_width-2) + "║",
            "║" + "You have successfully completed your mission!".center(box_width-2) + "║",
            "║" + " " * (box_width-2) + "║",
            "║" + "You've repaired the station and retrieved".center(box_width-2) + "║",
            "║" + "the energy crystal. The station's systems".center(box_width-2) + "║",
            "║" + "are coming back online.".center(box_width-2) + "║",
            "║" + " " * (box_width-2) + "║",
            "╟" + "─" * (box_width-2) + "╢",
            "║" + f"░▒▓█ Final Score: {self.player.score}".ljust(box_width-2) + "║",
            "║" + f"░▒▓█ Hazards Encountered: {self.player.hazard_count}".ljust(box_width-2) + "║",
            "╚" + "═" * (box_width-2) + "╝"
        ]
        return "\n".join(message)

# ... (rest of the code remains the same)

    def start_game(self):
        """Start the main game loop."""
        # Initialize the game world
        self.build_world()
        
        # Show the game intro
        self.show_intro()
        
        # Main game loop
        while True:
            # Display current room and status
            self.clear_screen()
            print(self.get_room_description(self.player.current_location))
            print(f"\n{self.player.get_status()}")
            
            # Get player input
            command = input("\nWhat would you like to do? ").strip().lower()
            
            # Process the command
            if command in ['quit', 'exit', 'q']:
                print(f"\n{Colors.YELLOW}▀█▀ █░█ ▄▀█ █▄░█ █▄▀ █▀   █▀▀ █▀█ █▀█   █▀█ █░░ ▄▀█ █▄█ █ █▄░█ █▀▀ █\n░█░ █▀█ █▀█ █░▀█ █░█ ▄█   █▀░ █▄█ █▀▄   █▀▀ █▄▄ █▀█ ░█░ █ █░▀█ █▄█ ▄{Colors.ENDC}\n")
                break
                
            # Process win command
            if command == 'win':
                if self.check_win_condition():
                    win_box = [
                        f"{Colors.CYAN}╔══════════════════════════════════════════════╗{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.CYAN}         ░▒▓█ {Colors.GREEN}MISSION ACCOMPLISHED{Colors.CYAN} █▓▒░         {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}╠══════════════════════════════════════════════╣{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}                                              {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}        You have successfully completed       {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}              your mission!                   {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}                                              {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}    You've repaired the station and retrieved {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}    the energy crystal. The station's systems {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}    are coming back online.                   {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.ENDC}                                              {Colors.CYAN}║{Colors.ENDC}",
                        f"{Colors.CYAN}╠──────────────────────────────────────────────╢{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.CYAN}    ░▒▓█{Colors.ENDC} Final Score: {str(self.player.score).ljust(22)}{Colors.CYAN} ║{Colors.ENDC}",
                        f"{Colors.CYAN}║{Colors.CYAN}    ░▒▓█{Colors.ENDC} Hazards Encountered: {str(self.player.hazard_count).ljust(11)}{Colors.CYAN} ║{Colors.ENDC}",
                        f"{Colors.CYAN}╚══════════════════════════════════════════════╝{Colors.ENDC}",
                        "",  # Add empty lines for spacing
                        ""   # Add empty lines for spacing
                    ]
                    print("\n" + "\n".join(win_box))
                    break
                else:
                    print("\nYou can't win yet. You need to have the energy crystal and be in the Docking Bay.")
                    input("\nPress any key to continue...")
                    continue
            
# ... (rest of the code remains the same)
            # Process movement commands
            if command in ['north', 'south', 'east', 'west', 'n', 's', 'e', 'w']:
                # Convert single-letter directions to full words
                direction_map = {'n': 'north', 's': 'south', 'e': 'east', 'w': 'west'}
                direction = direction_map.get(command, command)
                result = self.handle_movement(direction)
                print(f"\n{result}")
            # Process crystal pickup
            elif command == 'pick up crystal':
                result = self.handle_pick_up_crystal()
                print(f"\n{result}")
            # Process tool usage
            elif command == 'use tool':
                result = self.handle_use_tool()
                print(f"\n{result}")
            # Process other commands
            else:
                result = self.process_input(command)
                print(f"\n{result}")
            
            # Pause before continuing
            input("\nPress any key to continue...")
    
    def handle_droid_encounter(self) -> str:
        """Handle the droid encounter in the corridor."""
        self.clear_screen()
        self.show_dialog_box("ALERT", "Oh no! A malfunctioning maintenance Droid is blocking the way.")
        input("Press Enter to continue...")
        
        if not self.player.has_tool:
            self.clear_screen()
            self.show_dialog_box("NOTICE", "A diagnostic tool lays on the ground.")
            print("\n[1] Pick up the tool\n[2] Leave it")
            
            while True:
                choice = input("\nWhat will you do? (1-2): ").strip()
                if choice == "1":
                    self.player.has_tool = True
                    self.clear_screen()
                    self.show_dialog_box("INVENTORY UPDATED", "You picked up the diagnostic tool!")
                    input("\nPress any key to continue...")
                    return "You pick up the diagnostic tool. It hums softly in your hand."
                elif choice == "2":
                    return "You leave the tool on the ground."
                else:
                    print("Please enter 1 or 2.")
        return ""

    def move_player(self, direction: str) -> str:
        """Attempt to move the player in the given direction."""
        if not direction:
            return "Please specify a direction to move."

        current_room = self.get_current_room()
        
        # Check if the direction is valid for the current room
        if direction not in current_room.exits:
            return f"You can't go {direction} from here."
        
        next_room = current_room.exits[direction]
        
        # Check for droid blocking the path to docking bay
        if (direction == "east" and hasattr(current_room, 'droid_present') and 
            current_room.droid_present):
            if not self.player.has_tool:
                self.player.hazard_count += 1
                return ("A damaged maintenance droid blocks the path to the east! (Hazard +1)\n"
                       "You'll need to repair it with the diagnostic tool first.\n"
                       "Type 'use tool' to attempt to repair the droid.\n"
                       f"{self.player.get_status()}")
        
        # If we get here, move to the next room
        self.player.current_location = next_room
        next_room.visited = True
        
        # Return the room description
        return f"You move {direction}.\n\n{self.get_room_description(next_room)}"
        
    def look_around(self) -> str:
        """Return the current room's description and contents."""
        room = self.get_current_room()
        return self.get_room_description(room)
    
    def get_room_art(self, room_name: str) -> str:
        """Return ASCII art for the given room.
        
        Args:
            room_name: The name of the room
                
        Returns:
            str: ASCII art for the room
        """
        # Map style options - uncomment your preferred style
        
        # Double-Lined Box (Wide)
        return """
        ╔════════════════════════╗
        ║                        ║
        ║         [N]            ║
        ║          ^             ║
        ║          |             ║
        ║          |             ║
        ║   [W] <--+--> [E]      ║
        ⑎          |             ║
        ║          |             ║
        ║          v             ║
        ║         [S]            ║
        ║                        ║
        ╚════════════════════════╝
        """
        
        # Style 2: Compass Rose
        """
             N
             |
             |
        W----+----E
             |
             |
             S
        """
        
        # Style 3: Rounded Corners
        """
        ╭──────────────╮
        │    ╭────╮    │
        │    │    │    │
        │[N] │    │ [E]│
        │    ╰────╯    │
        │              │
        │[W]    +   [S]│
        ╰──────────────╯
        """
        
        # Style 4: Minimalist
        """
           N
           ↑
        W ←   → E
           ↓
           S
        """
        
        # Style 5: Detailed Box
        """
        ╔════════════════╗
        ║                ║
        ║    ╔════╗      ║
        ║    ║    ║      ║
        ║    ╚════╝      ║
        ║                ║
        ╚════════════════╝
        [N]            [E]
        [W]            [S]
        """

    def get_room_description(self, room: Location) -> str:
        """Generate a description of the room and its contents."""
        # Show room art
        room_art = self.get_room_art(room.name)
        
        # Center all text and the map
        def center_text(text, width=60):
            if not text.strip():
                return text
            return '\n'.join(line.center(width) for line in text.split('\n'))
            
        # Create a text box for the room description
        def create_text_box(title, text, width=50):
            box = []
            # Calculate the actual width needed (accounting for borders)
            content_width = width - 4  # 2 for borders + 1 space padding each side
            
            # Top border
            box.append('┌' + '─' * (width - 2) + '┐')
            
            # Title (centered within the box)
            title_line = f" {title} ".center(width - 2, ' ')
            box.append(f"│{title_line}│")
            
            # Middle border
            box.append('├' + '─' * (width - 2) + '┤')
            
            # Split text into lines that fit within the box
            words = text.split()
            current_line = []
            for word in words:
                if len(' '.join(current_line + [word])) <= content_width:
                    current_line.append(word)
                else:
                    line = ' ' + ' '.join(current_line).ljust(content_width + 1)  # +1 for the right space
                    box.append(f"│{line}│")
                    current_line = [word]
            
            # Add the last line
            if current_line:
                line = ' ' + ' '.join(current_line).ljust(content_width + 1)
                box.append(f"│{line}│")
            
            # Bottom border
            box.append('└' + '─' * (width - 2) + '┘')
            
            return '\n'.join(box)
            
        # Center the room title and description in a text box
        room_title = f"{Colors.HEADER}{room.name.upper()}{Colors.ENDC}"
        description_box = create_text_box(room_title, room.description, width=52)  # Slightly wider for better text wrapping
        description = [f"\n{center_text(description_box)}\n"]
        
        # List visible items
        visible_items = []
        if room.name == 'Engineering Bay' and room.has_tool:
            visible_items.append("- A diagnostic tool is on the ground (type 'pick up tool' to take it)")
        elif room.has_tool:
            visible_items.append("- A diagnostic tool is on the ground")
            
        if room.has_crystal:
            visible_items.append("- A glowing energy crystal sits on a pedestal (type 'pick up crystal' to take it)")
            
        if visible_items:
            description.append(center_text("\nYou see:"))
            description.extend(center_text(item) for item in visible_items)
        
        # List items in the room using the boolean flags
        if hasattr(room, 'has_tool') and room.has_tool:
            description.append(center_text("\nYou see a diagnostic tool on the ground."))
        if hasattr(room, 'has_crystal') and room.has_crystal:
            description.append(center_text("\nYou see an energy crystal glowing faintly."))
        if hasattr(room, 'droid_present') and room.droid_present:
            description.append(center_text("\nA damaged maintenance droid is blocking the way!"))
            
        # Add droid information if present
        if hasattr(room, 'droid') and room.droid:
            description.append(center_text("\nA damaged maintenance droid is blocking the way."))
            if self.player.has_tool:
                description.append(center_text("You could try to use your diagnostic tool on it."))
        
        # List available exits with the new double-lined box style
        # Prepare direction indicators with consistent spacing
        n_indicator = "[N]" if 'north' in room.exits else "   "
        s_indicator = "[S]" if 'south' in room.exits else "   "
        e_indicator = "[E]" if 'east' in room.exits else "   "
        w_indicator = "[W]" if 'west' in room.exits else "   "
        
        # Create the map with centered content
        map_width = 60
        map_content = f"""
╔═════════════╗
║             ║
║    {n_indicator}      ║
║      ^      ║
║      |      ║
║      |      ║
║{w_indicator}<--+-->{e_indicator}║
║      |      ║
║      |      ║
║      v      ║
║    {s_indicator}      ║
║             ║
╚═════════════╝"""
        
        # Center the map
        centered_map = []
        for line in map_content.strip().split('\n'):
            centered_map.append(line.center(map_width).rstrip())
        exit_art = f"{Colors.BLUE}" + '\n'.join(centered_map) + f"{Colors.ENDC}"
        
        description.append(f"\n{center_text(Colors.CYAN + 'Exits:' + Colors.ENDC)}\n{exit_art}")
        
        return "\n".join(description)
        room = self.get_current_room()
        if not room:
            print("Error: No current room!")
            return
            
        name = room.name.replace('_', ' ').title()
        exits = {d: (d in room.exits) for d in ['north', 'east', 'south', 'west']}

        # Room header with solid border (white box, blue text)
        header_width = 50
        indent = ' ' * 30  # Base indentation
        header_indent = ' ' * 33  # 32+1=33 spaces for header
        print(f"\n{header_indent}╔{'═' * (header_width - 2)}╗")
        print(f"{header_indent}║{Colors.BLUE}{name.upper():^{header_width-2}}{Colors.ENDC}║")
        print(f"{header_indent}╚{'═' * (header_width - 2)}╝")
        
        # Room description (blue, centered)
        desc_lines = wrap_text(room.description, width=60).split('\n')
        print()  # Extra newline for spacing
        for line in desc_lines:
            print(f"{indent}{Colors.BLUE}{line:^50}{Colors.ENDC}")
        print()  # Extra newline for spacing

        # Build room box with solid white borders (centered)
        box_w = 46
        box_indent = ' ' * 33  # 32+1=33 spaces for box
        room_top = f"{box_indent}╔{'═' * box_w}╗"
        room_mid = f"{box_indent}║{' ' * box_w}║"
        room_bot = f"{box_indent}╚{'═' * box_w}╝"

        # Exit indicators with clear labels (default terminal color)
        north_label = "NORTH [W/↑]" if exits['north'] else " " * 12
        south_label = "SOUTH [S/↓]" if exits['south'] else " " * 12
        west_label  = "WEST [A/←] " if exits['west']  else " " * 11
        east_label  = " EAST [D/→]" if exits['east']  else " " * 11

        # Print room with exit indicators (centered)
        print(f"{indent}   {north_label:^50}")
        print(room_top)
        for _ in range(8):
            print(room_mid)
        print(room_bot)
        print(f"{indent}   {west_label:^16}{' ' * 20}{east_label:^16}")
        print(f"{indent}   {south_label:^50}")
        print()  # Extra newline for spacing

        # Status line with white separator (centered)
        separator = '═' * 50
        print(f"\n{indent}    {separator}")
        
        status_line = f"{Colors.YELLOW}Score:{Colors.ENDC} {self.player.score}  |  {Colors.RED}Hazards:{Colors.ENDC} {self.player.hazard_count}"
        inventory_text = f"{Colors.GREEN}Inventory:{Colors.ENDC} " + (', '.join([item.name for item in self.player.inventory]) if self.player.inventory else "Empty")
        
        print(f"{indent}              {status_line:^50}")
        print(f"{indent}           {inventory_text:^50}")
        print(f"\n{indent}  {Colors.GREY}Move with W/A/S/D or direction words. Type 'help' for commands.{Colors.ENDC}")
    
    def take_item(self, item_name: str) -> str:
        """Attempt to take an item from the current room."""
        room = self.get_current_room()
        item_name = item_name.lower()
        
        if item_name in ['tool', 'diagnostic tool'] and hasattr(room, 'has_tool') and room.has_tool:
            room.has_tool = False
            self.player.has_tool = True
            self.player.score += 10
            return "You take the diagnostic tool. It hums softly in your hand. (+10)"
            
        if item_name in ['crystal', 'energy crystal'] and hasattr(room, 'has_crystal') and room.has_crystal:
            room.has_crystal = False
            self.player.has_crystal = True
            self.player.score += 50
            return "You carefully pick up the energy crystal. It pulses with a warm light. (+50)"
            
        return "I don't see that here."
    
    def use_item(self, item_name: str, target: str) -> str:
        """Attempt to use an item on a target."""
        if not self.player.has_item(item_name):
            return f"You don't have a {item_name}."
            
        if self.player.use_item(item_name, target):
            if item_name.lower() == "diagnostic tool" and target.lower() == "damaged maintenance droid":
                return ("You use the Diagnostic Tool on the Damaged Maintenance Droid. "
                       "It whirs to life and moves out of the way!")
        
        return f"You can't use {item_name} on {target}."
    
    def show_inventory(self) -> str:
        """Show the player's inventory with item descriptions."""
        # Get all items from inventory
        items = []
        
        # Add items from inventory list
        if hasattr(self.player, 'inventory') and self.player.inventory:
            items.extend([item for item in self.player.inventory if hasattr(item, 'name')])
        
        # Add special items if they're not already included
        if self.player.has_tool and not any(isinstance(item, DiagnosticTool) for item in items):
            items.append(DiagnosticTool())
        if self.player.has_crystal and not any(isinstance(item, EnergyCrystal) for item in items):
            items.append(EnergyCrystal())
        
        if not items:
            return "Your inventory is empty."
        
        # Format the inventory with item names and descriptions
        inventory_list = []
        for item in items:
            description = item.examine() if hasattr(item, 'examine') else f"A {item.name}."
            inventory_list.append(f"- {item.name}: {description}")
        
        return "Your inventory contains:\n" + "\n".join(inventory_list)
    
    def show_score(self) -> str:
        """Show the player's current score and hazards."""
        return f"Score: {self.player.score} | Hazards: {self.player.hazards}"
    
    def show_help(self) -> str:
        """Return help text with available commands.
        
        Returns:
            str: Formatted help text with available commands
        """
        return self.get_help_text()
    
    def attempt_win(self) -> str:
        """Check win conditions and handle the winning scenario.
        
        Implements the Template Method pattern by defining the algorithm's structure
        with specific steps that can be overridden by subclasses if needed.
        
        Returns:
            str: Win message or reason why player can't win yet
        """
        # Chain of Responsibility pattern - each condition checks if it can handle the request
        if self.player.current_room != "docking_bay":
            return "You can't win from here. You need to be in the Docking Bay."
            
        # State validation - ensures game rules are followed
        if not self.player.droid_repaired:
            return "You haven't completed all the required tasks yet!"
            
        # Inventory check - demonstrates encapsulation of player's inventory
        if not self.player.has_item("Energy Crystal"):
            return "You need the Energy Crystal to complete the mission!"
            
        # Update game state - follows Command pattern by encapsulating the action
        self.player.score += 30  # Final score bonus
        self.game_over = True    # State transition
        
        # Return formatted UI component - follows Builder pattern for complex string construction
        return (
            f"{Colors.CYAN}╔══════════════════════════════════════════╗{Colors.ENDC}\n"
            f"{Colors.CYAN}║{Colors.CYAN}        ░▒▓█ {Colors.GREEN}MISSION COMPLETE{Colors.CYAN} █▓▒░        {Colors.CYAN}║{Colors.ENDC}\n"
            f"{Colors.CYAN}╠══════════════════════════════════════════╣{Colors.ENDC}\n"
            f"{Colors.CYAN}║{Colors.ENDC}    • {Colors.YELLOW}Final Score:{Colors.ENDC} {str(self.player.score).ljust(22)}{Colors.CYAN} ║{Colors.ENDC}\n"
            f"{Colors.CYAN}║{Colors.ENDC}    • {Colors.YELLOW}Hazards Encountered:{Colors.ENDC} {str(self.player.hazards).ljust(11)}{Colors.CYAN} ║{Colors.ENDC}\n"
            f"{Colors.CYAN}╚══════════════════════════════════════════╝{Colors.ENDC}\n\n\n"
        )

    def show_intro(self) -> None:
        """World-creation intro: Sergeant Joe + red notification."""
        # Safe terminal width
        try:
            terminal_width = os.get_terminal_size().columns
        except (OSError, AttributeError):
            terminal_width = 80

        def center_line(s: str) -> str:
            pad = max(0, (terminal_width - len(s)) // 2)
            return ' ' * pad + s

        def type_print(s: str, delay: float = 0.01):
            for ch in s:
                print(ch, end='', flush=True)
                time.sleep(delay)

        def show_dialog_box(name: str, text: str, border_color: str = Colors.CYAN, name_color: str = Colors.YELLOW):
            inner_text = text
            name_tag = f" {name} "
            inner_width = max(len(inner_text) + 2, len(name_tag) + 4)
            box_width = inner_width + 2

            left = max(0, (terminal_width - box_width) // 2)
            top = ' ' * left + f"{border_color}┌" + '─' * inner_width + f"┐{Colors.ENDC}"
            name_line = ' ' * left + f"{border_color}│{Colors.ENDC}" + f"{name_color}{name_tag}{Colors.ENDC}" + \
                        ' ' * (inner_width - len(name_tag)) + f"{border_color}│{Colors.ENDC}"
            text_pad = max(0, inner_width - (len(inner_text) + 2))
            mid_prefix = ' ' * left + f"{border_color}│{Colors.ENDC} "
            mid_suffix = ' ' + ' ' * text_pad + f"{border_color}│{Colors.ENDC}"
            bottom = ' ' * left + f"{border_color}└" + '─' * inner_width + f"┘{Colors.ENDC}"

            print()
            print(top)
            print(name_line)
            type_print(mid_prefix + inner_text + mid_suffix, delay=0.01)
            print()
            print(bottom)

        # Show three dialog boxes (no ASCII title)
        self.clear_screen()

        dialogs = [
            ("Sergeant Joe", "Hi there! I'm Sergeant Joe, El Capitan of the Astrothunder Ship.", Colors.CYAN, Colors.YELLOW),
            ("Sergeant Joe", "Here is your telewatch buddy Genesis, it will inform you on anything you have to do.", Colors.CYAN, Colors.YELLOW),
            ("Sergeant Joe", "Good luck and welcome to the crew!", Colors.CYAN, Colors.YELLOW),
            ("Genesis", "Hi there! I'm Genesis, your telewatch buddy. I'll inform you on anything you have to do.", Colors.GREEN, Colors.YELLOW),
            ("Genesis", "I'll keep you updated on anything that happens.", Colors.GREEN, Colors.YELLOW),
            ("Genesis", "! WARNING ! You need to repair the droids in the maintenance tunnels before you can DESTROY THE SHIP.", Colors.RED, Colors.YELLOW),
        ]
        for speaker, text, border_color, name_color in dialogs:
            show_dialog_box(speaker, text, border_color, name_color)
            prompt = center_line(f"{Colors.BOLD}[Press Enter to continue]{Colors.ENDC}")
            input('\n' + prompt)
            # Clear between dialogs so each appears on a fresh screen
            self.clear_screen()

        # Clear the screen after the last dialog
        self.clear_screen()

    
