"""
Game Objects Module

Contains base classes for all game entities and objects.
"""
from typing import List, Optional, Dict, Any
import random
from .items import DiagnosticTool, Crowbar, EnergyCrystal, CRATE_LOOT

class StationItem:
    """Base class for all items that can be picked up in the game."""
    def __init__(self, name: str, description: str):
        self._name = name
        self._description = description
    
    def examine(self) -> str:
        """Return a description of the item."""
        return self._description
    
    @property
    def name(self) -> str:
        """Get the name of the item."""
        return self._name


class Location:
    """Represents a location in the game world.
    
    Each location can hold exactly one tool, one crystal, and/or the droid.
    """
    def __init__(self, name: str, description: str):
        """Initialize the location's name, description, and default flags.
        
        Args:
            name: The name of the location
            description: A description of the location
        """
        self.name = name
        self.description = description
        self.exits = {}  # Maps direction to Location objects
        self.has_tool = False
        self.has_crystal = False
        self.droid_present = False
        self.visited = False  # Track if player has visited this location
        
    def describe(self) -> str:
        """Return a formatted description of the location.
        
        Returns:
            str: A formatted string describing the location and its contents
        """
        description = f"{self.name}\n{self.description}\n"
        
        if self.has_tool:
            description += "You see a diagnostic tool here.\n"
        if self.has_crystal:
            description += "You see an energy crystal here.\n"
        if self.droid_present:
            description += "A maintenance droid blocks the way!\n"
            
        # Add exits
        if self.exits:
            exit_directions = ", ".join(self.exits.keys())
            description += f"Exits: {exit_directions}."
            
        return description
    
    def add_exit(self, direction: str, other_location: 'Location') -> None:
        """Record that a given direction leads to another Location.
        
        Args:
            direction: The direction of the exit (e.g., 'north', 'east').
            other_location: The Location object this exit leads to.
        """
        self.exits[direction.lower()] = other_location
        
    def remove_tool(self) -> bool:
        """Remove the tool from this location if present.
        
        Returns:
            bool: True if a tool was removed, False otherwise.
        """
        if self.has_tool:
            self.has_tool = False
            return True
        return False
        
    def remove_crystal(self) -> bool:
        """Remove the crystal from this location if present.
        
        Returns:
            bool: True if a crystal was removed, False otherwise.
        """
        if self.has_crystal:
            self.has_crystal = False
            return True
        return False
        
    def set_droid_present(self, flag: bool) -> None:
        """Set whether a droid is present in this location.
        
        Args:
            flag: True if a droid should be present, False otherwise.
        """
        self.droid_present = flag
    
    def remove_tool(self) -> bool:
        """Remove the tool from this location if present.
        
        Returns:
            bool: True if a tool was removed, False otherwise.
        """
        if self.has_tool:
            self.has_tool = False
            return True
        return False
    
    def remove_crystal(self) -> bool:
        """Remove the crystal from this location if present.
        
        Returns:
            bool: True if a crystal was removed, False otherwise.
        """
        if self.has_crystal:
            self.has_crystal = False
            return True
        return False
    
    def set_droid_present(self, flag: bool) -> None:
        """Set whether the droid is present in this location.
        
        Args:
            flag: True if droid is present, False otherwise.
        """
        self.droid_present = flag
    
    def describe(self) -> str:
        """Generate a description of this location and its contents.
        
        Returns:
            str: A formatted description of the location.
        """
        if not self.visited:
            self.visited = True
            self.initialize_crates(3)  # Initialize crates when first visiting
            
        description = [f"\n{self.name.upper()}", "=" * len(self.name), self.description]
        
        # List visible items and crates
        visible_items = []
        if self.items:
            visible_items.extend([f"- {item.name}" for item in self.items])
            
        # Add crates to visible items
        if self.crates:
            visible_items.extend([f"- {crate.name} (crate)" for crate in self.crates])
            
        if visible_items:
            description.append("\nYou see:" + "\n".join([""] + visible_items))
                
        # List exits
        if self.exits:
            exit_dirs = ", ".join(self.exits.keys())
            description.append(f"\nExits: {exit_dirs}")
            
        return "\n".join(description)


class DamagedMaintenanceDroid:
    """Represents a damaged maintenance droid that blocks passage."""
    
    def __init__(self):
        """Initialize the droid as blocking by default."""
        self.blocking = True
        
    def repair(self) -> None:
        """Repair the droid so it no longer blocks passage."""
        self.blocking = False
        
    def is_blocking(self) -> bool:
        """Check if the droid is still blocking.
        
        Returns:
            bool: True if the droid is blocking, False otherwise.
        """
        return self.blocking


class Player:
    """Represents the player character in the game."""
    def __init__(self, starting_location):
        """Initialize the player with a starting location.
        
        Args:
            starting_location: The initial Location object for the player.
        """
        self.current_location = starting_location
        self.inventory = []
        self.has_tool = False
        self.has_crystal = False
        self.score = 0
        self.hazard_count = 0
    
    def move(self, direction: str) -> bool:
        """Attempt to move the player in the given direction.
        
        Args:
            direction: The direction to move (e.g., 'north', 'east').
            
        Returns:
            bool: True if the move was successful, False otherwise.
        """
        direction = direction.lower()
        if direction not in self.current_location.exits:
            return False
            
        next_location = self.current_location.exits[direction]
        
        # Check for blocking droid
        if hasattr(next_location, 'droid_present') and next_location.droid_present:
            self.hazard_count += 1
            return False
            
        self.current_location = next_location
        return True
    
    def pick_up_tool(self) -> bool:
        """Attempt to pick up a diagnostic tool from the current location.
        
        Returns:
            bool: True if successful, False otherwise.
        """
        if self.current_location.has_tool and not self.has_tool:
            # Create a new diagnostic tool instance
            from .items import DiagnosticTool
            tool = DiagnosticTool()
            
            # Add to inventory
            self.inventory.append(tool)
            self.has_tool = True
            self.current_location.has_tool = False
            self.score += 10
            return True
        return False
        
    def use_tool_on_droid(self) -> bool:
        """Use the diagnostic tool on a droid in the current location.
        
        Returns:
            bool: True if successful, False otherwise.
        """
        if (self.has_tool and hasattr(self.current_location, 'droid_present') 
                and self.current_location.droid_present):
            self.current_location.droid_present = False
            self.score += 20
            return True
        return False
        
    def pick_up_crystal(self) -> bool:
        """Attempt to pick up an energy crystal from the current location.
        
        Returns:
            bool: True if successful, False otherwise.
        """
        if hasattr(self.current_location, 'has_crystal') and self.current_location.has_crystal and not self.has_crystal:
            # Create a new energy crystal instance
            from .items import EnergyCrystal
            crystal = EnergyCrystal()
            
            # Add to inventory
            self.inventory.append(crystal)
            self.has_crystal = True
            self.current_location.has_crystal = False
            self.score += 50
            return True
        return False
        
    def get_status(self) -> str:
        """Get the player's current status.
        
        Returns:
            str: A string showing the player's current score and hazard count.
        """
        return f"Score: {self.score} Hazards: {self.hazard_count}."
        
        # Check for droid in current location or in encountered_droid
        if hasattr(self.current_location, 'droid') and self.current_location.droid:
            target_droid = self.current_location.droid
        elif self.encountered_droid:
            target_droid = self.encountered_droid
            
        if target_droid and self.has_tool:
            target_droid.repair()
            self.score += 20  # Increased from 10 to 20 as per requirements
            # If this was an encountered droid, clear the encounter
            if self.encountered_droid == target_droid:
                self.encountered_droid = None
            return True
        return False
    
    def pick_up_crystal(self):
        """Attempt to pick up an energy crystal from the current location.
        
        Returns:
            bool: True if successful, False otherwise.
        """
        if self.current_location.has_crystal and not self.has_crystal:
            crystal = next((item for item in self.current_location.items 
                          if isinstance(item, EnergyCrystal)), None)
            if crystal:
                self.add_item(crystal)
                self.current_location.items.remove(crystal)
                self.current_location.has_crystal = False
                self.score += 50  # Increased from 20 to 50 as per requirements
                return True
        return False
    
    def get_status(self) -> str:
        """Get the player's current status.
        
        Returns:
            str: A string showing the player's current score and hazard count.
        """
        return f"Score: {self.score} | Hazards: {self.hazard_count}"
        
    def examine(self, target: str) -> str:
        """Examine an object in the current location.
        
        Args:
            target: The name of the object to examine.
            
        Returns:
            str: A description of the object.
        """
        target = target.lower()
        
        # Check inventory first
        if hasattr(self, 'inventory'):
            for item in self.inventory:
                if hasattr(item, 'name') and item.name.lower() == target:
                    return item.examine() if hasattr(item, 'examine') else f"It's a {item.name}."
        
        # Check special items in current location
        if target == 'tool' and self.current_location.has_tool:
            return "A diagnostic tool used for repairing electronic equipment. It's still in good condition."
            
        if target == 'crystal' and self.current_location.has_crystal:
            return "A glowing energy crystal. It pulses with a warm light."
            
        if target == 'droid' and hasattr(self.current_location, 'droid_present') and self.current_location.droid_present:
            return "A damaged maintenance droid. It's blocking the path to the east. It looks like it needs to be repaired with a diagnostic tool."
        
        # Check location items
        if hasattr(self.current_location, 'items'):
            for item in self.current_location.items:
                if hasattr(item, 'name') and item.name.lower() == target:
                    return item.examine() if hasattr(item, 'examine') else f"It's a {item.name}."
        
        # Check crates if they exist in the location
        if hasattr(self.current_location, 'crates'):
            for crate in self.current_location.crates:
                if hasattr(crate, 'name') and crate.name.lower() == target:
                    return crate.examine() if hasattr(crate, 'examine') else f"It's a {crate.name}."
        
        return f"You don't see a '{target}' here to examine."
        
    def search_crates(self) -> str:
        """Search through crates in the current location.
        
        Returns:
            str: The result of searching the crates.
        """
        if not hasattr(self.current_location, 'crates') or not self.current_location.crates:
            return "There are no crates to search in this area."
            
        # Initialize crates if not already done
        if not hasattr(self.current_location, '_initialized_crates') or not self.current_location._initialized_crates:
            self.current_location.initialize_crates()
            
        # Show crate selection menu
        response = ["Search which crate?\n"]
        for i, crate in enumerate(self.current_location.crates, 1):
            status = "(locked)" if crate.is_locked and not crate.is_open else ""
            response.append(f"{i}. {crate.name} {status}")
        response.append("\nEnter the number of the crate to search, or 'back' to cancel.")
        
        return "\n".join(response)
        
    def open_crate(self, crate_name: str) -> str:
        """Attempt to open a crate.
        
        Args:
            crate_name: The name or number of the crate to open.
            
        Returns:
            str: The result of the attempt.
        """
        # Handle numeric input (1, 2, 3)
        if crate_name.isdigit():
            crate_num = int(crate_name)
            if 1 <= crate_num <= len(self.current_location.crates):
                crate = self.current_location.crates[crate_num - 1]
            else:
                return "Invalid crate number."
        else:
            # Handle text input ("crate 1", "crate1", etc.)
            crate_name = crate_name.lower().replace('crate', '').strip()
            if crate_name.isdigit():
                return self.open_crate(crate_name)  # Recursively handle numeric input
                
            crate = next((c for c in self.current_location.crates 
                         if c.name.lower() == f"crate {crate_name}" or 
                            c.name.lower() == crate_name.lower()), None)
        
        if not crate:
            return "You don't see that crate here."
            
        if crate.is_locked:
            if self.has_item("crowbar"):
                crate.is_locked = False
                crate.is_open = True
                if crate.contents:
                    items = ", ".join(item.name for item in crate.contents)
                    for item in crate.contents:
                        self.add_item(item)
                    crate.contents.clear()
                    return f"You use the crowbar to force open the crate and find: {items}"
                return "You use the crowbar to open the crate, but it's empty."
            else:
                return "This crate is locked. You'll need a crowbar to open it."
                
        # If we get here, the crate is not locked
        crate.is_open = True
        if crate.contents:
            items = ", ".join(item.name for item in crate.contents)
            for item in crate.contents:
                self.add_item(item)
            crate.contents.clear()
            return f"You open the crate and find: {items}"
        return "You open the crate, but it's empty."
            
    def take_item(self, item_name: str) -> str:
        """Take an item from the current location.
        
        Args:
            item_name: The name of the item to take.
            
        Returns:
            str: The result of the attempt.
        """
        item_name = item_name.lower()
        
        # Check if trying to take the tool or crystal directly
        if item_name == 'tool' and self.current_location.has_tool:
            self.has_tool = True
            self.current_location.has_tool = False
            self.score += 10
            return "You take the diagnostic tool. (+10)"
            
        if item_name == 'crystal' and self.current_location.has_crystal:
            self.has_crystal = True
            self.current_location.has_crystal = False
            self.score += 50
            return "You take the energy crystal. (+50)"
            
        # For other items, check the location's items list
        item = next((i for i in self.current_location.items 
                    if i.name.lower() == item_name), None)
                    
        if not item:
            return f"You don't see a '{item_name}' here to take."
            
        if not hasattr(item, 'is_takeable') or not item.is_takeable:
            return f"You can't take the {item.name}."
            
        # Add to inventory and remove from location
        self.inventory.append(item)
        self.current_location.items.remove(item)
        return f"You take the {item.name}."
        
    def attempt_sneak_past_droid(self) -> bool:
        """Attempt to sneak past the droid.
        
        Returns:
            bool: True if successful, False otherwise (50/50 chance)
        """
        import random
        if not self.encountered_droid:
            return False
            
        success = random.choice([True, False])
        if success:
            self.encountered_droid = None
            return True
        else:
            self.hazard_count += 1
            return False
