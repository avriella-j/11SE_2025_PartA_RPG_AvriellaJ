"""
Items Module

Contains all item classes for the game.
"""
from typing import List, Dict, Optional

class Item:
    """Base class for all items in the game."""
    def __init__(self, name: str, description: str, is_takeable: bool = True):
        self.name = name
        self.description = description
        self.is_takeable = is_takeable
        self.is_locked = False
        self.contents: List[Item] = []

    def examine(self) -> str:
        """Return a detailed description of the item."""
        desc = [f"{self.name.upper()}", "=" * len(self.name), self.description]
        if hasattr(self, 'contents') and self.contents:
            desc.append("\nIt contains:")
            for item in self.contents:
                desc.append(f"- {item.name}")
        return "\n".join(desc)


class Container(Item):
    """An item that can contain other items."""
    def __init__(self, name: str, description: str, is_locked: bool = False):
        super().__init__(name, description)
        self.is_locked = is_locked
        self.is_open = False

    def examine(self) -> str:
        """Return a description of the container and its contents if open."""
        desc = [f"{self.name.upper()}", "=" * len(self.name), self.description]
        
        if self.is_locked and not self.is_open:
            desc.append("It appears to be locked.")
        elif self.is_open and hasattr(self, 'contents') and self.contents:
            desc.append("It's open and contains:")
            for item in self.contents:
                desc.append(f"- {item.name}")
        elif self.is_open:
            desc.append("It's open but empty.")
        else:
            desc.append("It's closed.")
            
        return "\n".join(desc)

    def unlock(self, key: 'Item' = None) -> bool:
        """Attempt to unlock the container."""
        if not self.is_locked:
            return True
            
        if isinstance(key, Crowbar):
            self.is_locked = False
            return True
            
        return False

    def open(self, key: 'Item' = None) -> bool:
        """Attempt to open the container."""
        if self.is_locked and not self.unlock(key):
            return False
            
        self.is_open = True
        return True

class Tool(Item):
    """Base class for tools in the game."""
    def __init__(self, name: str, description: str, is_takeable: bool = True):
        super().__init__(name, description, is_takeable)

class Crowbar(Tool):
    """A sturdy crowbar that can be used to open locked crates."""
    def __init__(self):
        super().__init__(
            "crowbar",
            "A heavy metal crowbar. Useful for prying open locked containers."
        )

class DiagnosticTool(Tool):
    """Tool used to repair the maintenance droid."""
    def __init__(self):
        super().__init__(
            "diagnostic tool",
            "A handheld device with various probes and readouts. It seems designed to interface with maintenance droids."
        )

class EnergyCrystal(Item):
    """Volatile crystal that powers the station's core."""
    def __init__(self):
        super().__init__(
            "energy crystal",
            "A glowing crystal pulsing with unstable energy. It radiates a faint warmth.",
            is_takeable=True
        )

# Create some common crate items that can appear in crates
CRATE_LOOT = [
    Item("wrench", "A standard issue maintenance wrench."),
    Item("data pad", "A cracked data pad with corrupted files."),
    Item("protein bar", "An unappetizing but nutritious protein bar."),
    Item("spare parts", "Assorted mechanical parts that might be useful."),
    Item("flashlight", "A small but bright flashlight."),
    Item("first aid kit", "A basic medical kit with bandages and antiseptic."),
    Item("coffee mug", "A chipped mug with 'World's Best Engineer' printed on it.")
]
