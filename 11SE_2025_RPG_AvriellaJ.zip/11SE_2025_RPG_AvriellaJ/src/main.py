"""
Main Module

Entry point for the Space Station Repair Mission text-based adventure game.
"""
import sys
import os
import time
from typing import Optional

# ANSI color codes
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# Game title as ASCII art
def show_title():
    """Display the game title with colored strips."""
    # Split the ASCII art into lines for color application
    title_lines = [
        " ░█████╗░░██████╗████████╗██████╗░░█████╗░████████╗██╗░░██╗██╗░░░██╗███╗░░██╗██████╗░███████╗██████╗░",
        "██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝██║░░██║██║░░░██║████╗░██║██╔══██╗██╔════╝██╔══██╗",
        "███████║╚█████╗░░░░██║░░░██████╔╝██║░░██║░░░██║░░░███████║██║░░░██║██╔██╗██║██║░░██║█████╗░░██████╔╝",
        "██╔══██║░╚═══██╗░░░██║░░░██╔══██╗██║░░██║░░░██║░░░██╔══██║██║░░░██║██║╚████║██║░░██║██╔══╝░░██╔══██╗",
        "██║░░██║██████╔╝░░░██║░░░██║░░██║╚█████╔╝░░░██║░░░██║░░██║╚██████╔╝██║░╚███║██████╔╝███████╗██║░░██║",
        "╚═╝░░╚═╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚═╝░░╚═╝░╚═════╝░╚═╝░░╚══╝╚═════╝░╚══════╝╚═╝░░╚═╝"
    ]
    
    # Get terminal width for centering, with fallback for non-TTY environments
    try:
        terminal_width = os.get_terminal_size().columns
    except (OSError, AttributeError):
        terminal_width = 80
    
    # Calculate the maximum line length (all lines are the same length)
    line_length = len(title_lines[0]) if title_lines else 0
    
    # Calculate left padding to center the title block
    left_padding = max(0, (terminal_width - line_length) // 2)
    
    # Print each line with consistent left padding
    for i, line in enumerate(title_lines):
        # Apply color based on line position
        if i < 2:  # First two lines in magenta
            colored_line = f"{Colors.HEADER}{line}{Colors.ENDC}"
        elif 2 <= i < 4:  # Next two lines in yellow
            colored_line = f"{Colors.YELLOW}{line}{Colors.ENDC}"
        else:  # Last two lines in cyan
            colored_line = f"{Colors.CYAN}{line}{Colors.ENDC}"
        
        # Print with consistent left padding
        print(" " * left_padding + colored_line)
    
    # Add centered subtitle with consistent padding
    subtitle = "SPACE STATION REPAIR MISSION"
    subtitle_padding = left_padding + (line_length - len(subtitle)) // 2
    print("\n" + " " * subtitle_padding + f"{Colors.HEADER}{subtitle}{Colors.ENDC}\n")

def clear_screen():
    """Clear the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def show_menu() -> str:
    """Display the main menu with arrow key navigation and a highlighted box."""
    import msvcrt  # Reliable keyboard input on Windows consoles

    # Menu options
    menu_items = [
        "1. New Game",
        "2. How to Play",
        "3. Quit"
    ]

    current_selection = 0

    while True:
        clear_screen()
        show_title()

        # Get terminal width for centering, default to 80 if can't determine
        try:
            terminal_width = os.get_terminal_size().columns
        except (OSError, AttributeError):
            terminal_width = 80

        # Box drawing characters
        top_left = '╔'
        top_right = '╗'
        bottom_left = '╚'
        bottom_right = '╝'
        horizontal = '═'
        vertical = '║'

        # Calculate box width (longest item + padding)
        # We need to ensure the box is wide enough for:
        # - Non-selected line: "  {item}  " inside the main box
        # - Selected line: label "» {item} «" inside the sub-box (which itself sits inside the main box with 1 padding on each side)
        # - The title "MAIN MENU"
        longest_item = max(len(item) for item in menu_items)
        longest_label = longest_item + 4  # accounts for "» " and " «"
        title_len = len("MAIN MENU")

        # Derive required outer box width
        # Non-selected requires: box_width >= len("  "+item+"  ") + 2 (borders)
        required_non_selected = longest_item + 4 + 2
        # Selected requires: inner_width - 4 >= len(label)  => box_width - 6 >= len(label) => box_width >= len(label) + 6
        required_selected = longest_label + 6
        # Title requires: box_width - 2 >= title_len => box_width >= title_len + 2
        required_title = title_len + 2

        # Pick the maximum and add a little breathing room
        box_width = max(required_non_selected, required_selected, required_title, 30)

        # Center the box
        box_padding = (terminal_width - box_width) // 2

        # Print top border
        print(' ' * box_padding + top_left + horizontal * (box_width - 2) + top_right)

        # Print title
        title = "MAIN MENU"
        title_padding = (box_width - len(title) - 2) // 2
        print(' ' * box_padding + vertical + ' ' * title_padding +
              f"{Colors.YELLOW}{title}{Colors.ENDC}" +
              ' ' * (box_width - title_padding - len(title) - 2) + vertical)

        # Print separator line
        print(' ' * box_padding + '╠' + '═' * (box_width - 2) + '╣')

        # Inner width for content between the main box borders
        inner_width = box_width - 2

        # Print menu items with a highlighted sub-box around the selected one
        for i, item in enumerate(menu_items):
            if i == current_selection:
                # Sizes for the highlighted sub-box
                sub_inner = inner_width - 2  # leave one space padding on left/right
                label = f"» {item} «"
                side_pad = max(0, (sub_inner - 2 - len(label)) // 2)

                # Top of sub-box
                print(
                    ' ' * box_padding + vertical + ' ' +
                    f"{Colors.CYAN}┌" + '─' * (sub_inner - 2) + f"┐{Colors.ENDC}" +
                    ' ' + vertical
                )
                # Middle with label
                print(
                    ' ' * box_padding + vertical + ' ' +
                    f"{Colors.CYAN}│{Colors.ENDC}" +
                    ' ' * side_pad + f"{Colors.BOLD}{label}{Colors.ENDC}" +
                    ' ' * (sub_inner - 2 - side_pad - len(label)) +
                    f"{Colors.CYAN}│{Colors.ENDC}" +
                    ' ' + vertical
                )
                # Bottom of sub-box
                print(
                    ' ' * box_padding + vertical + ' ' +
                    f"{Colors.CYAN}└" + '─' * (sub_inner - 2) + f"┘{Colors.ENDC}" +
                    ' ' + vertical
                )
            else:
                # Non-selected item, single centered line
                line = f"  {item}  "
                content_pad = max(0, (inner_width - len(line)) // 2)
                print(' ' * box_padding + vertical +
                      ' ' * content_pad + f"{Colors.GREEN}{line}{Colors.ENDC}" +
                      ' ' * (inner_width - content_pad - len(line)) + vertical)

        # Print bottom border
        print(' ' * box_padding + bottom_left + horizontal * (box_width - 2) + bottom_right)

        # Print instructions
        instructions = "↑/↓: Navigate    ENTER: Select    ESC: Quit"
        instructions_padding = max(0, (terminal_width - len(instructions)) // 2)
        print("\n" + " " * instructions_padding + f"{Colors.YELLOW}{instructions}{Colors.ENDC}")
        # Ensure the UI is rendered before waiting for key input (important for some IDE terminals)
        try:
            import sys as _sys
            _sys.stdout.flush()
        except Exception:
            pass

        # Wait for a key and update selection; fallback to numeric input if necessary
        try:
            ch = msvcrt.getwch()
            if ch in ('\r', '\n'):
                return str(current_selection + 1)
            if ch == '\x1b':  # ESC
                return '3'
            if ch == '\xe0' or ch == '\x00':  # Special key prefix
                ch2 = msvcrt.getwch()
                if ch2 == 'H':  # Up arrow
                    current_selection = (current_selection - 1) % len(menu_items)
                elif ch2 == 'P':  # Down arrow
                    current_selection = (current_selection + 1) % len(menu_items)
        except Exception:
            # Fallback: show numeric prompt centered
            prompt = "Enter your choice (1-3): "
            p_pad = max(0, (terminal_width - len(prompt)) // 2)
            try:
                choice = input("\n" + " " * p_pad + prompt).strip()
                if choice in ('1','2','3'):
                    return choice
            except (EOFError, KeyboardInterrupt):
                return '3'

def center_text(text: str, width: int) -> str:
    """Center text within a given width."""
    lines = text.split('\n')
    centered_lines = []
    for line in lines:
        padding = max(0, (width - len(line)) // 2)
        centered_lines.append(' ' * padding + line)
    return '\n'.join(centered_lines)

def show_instructions():
    """Display centered game instructions."""
    clear_screen()
    # Get terminal width safely with fallback
    try:
        terminal_width = os.get_terminal_size().columns
    except (OSError, AttributeError):
        terminal_width = 80
    
    # Create the instructions text with color codes
    # Calculate the maximum command width for alignment
    commands = [
        ("look", "Look around the current room"),
        ("take <item>", "Pick up an item"),
        ("use <item>", "Use an item from your inventory"),
        ("north/south/east/west", "Move in that direction"),
        ("status", "Check your score and items"),
        ("help", "Show available commands"),
        ("quit", "Quit the game")
    ]
    
    sections = [
        (f"{Colors.CYAN}█░█ █▀█ █░█░█   ▀█▀ █▀█   █▀█ █░░ ▄▀█ █▄█\n{Colors.CYAN}            █▀█ █▄█ ▀▄▀▄▀   ░█░ █▄█   █▀▀ █▄▄ █▀█ ░█░{Colors.ENDC}", ""),
        (f"You are a technician aboard the space station Epsilon-7. The station's "
         f"power core is failing, and you need to retrieve the energy crystal from "
         f"the docking bay to stabilize it. However, a damaged maintenance droid is "
         f"blocking the way. Find the diagnostic tool to repair it!{Colors.ENDC}", ""),
        (f"{Colors.CYAN}Available Commands:{Colors.ENDC}", "")
    ]
    
    # Add commands with perfect centering and alignment
    box_width = 18  # Slightly reduced width for better proportions
    for cmd, desc in commands:
        if '/' in cmd:  # Handle multi-line commands
            parts = cmd.split('/')
            box = f"{Colors.CYAN}┌{'─'*box_width}┐\n"
            for i, part in enumerate(parts):
                if i < len(parts) - 1:
                    line = (part + '/').center(box_width)
                else:
                    line = part.center(box_width)
                box += f"│{line}│\n"
            box += f"└{'─'*box_width}┘{Colors.ENDC}"
        else:
            box = f"{Colors.CYAN}┌{'─'*box_width}┐\n│{cmd.center(box_width)}│\n└{'─'*box_width}┘{Colors.ENDC}"
        
        # Add consistent left padding to align all boxes
        padding = ' ' * 20  # Adjusted padding for perfect centering
        box = '\n'.join(padding + line for line in box.split('\n'))
        sections.append((box, f"{Colors.CYAN}-{Colors.ENDC} {desc}"))
    
    # Add the final sections
    sections.extend([
        ("", ""),
        (f"{Colors.BOLD}Press Enter to return to the main menu...{Colors.ENDC}", "")
    ])
    
    # Calculate the maximum line length for centering
    max_length = max(
        len(section[0].replace('\033[95m', '').replace('\033[94m', '').replace('\033[96m', '')
                  .replace('\033[92m', '').replace('\033[93m', '').replace('\033[91m', '')
                  .replace('\033[0m', '').replace('\033[1m', '')) + len(section[1])
        for section in sections
    )
    
    # Print each centered line
    for command, description in sections:
        if not command and not description:
            print()  # Empty line
            continue
            
        # Format command and description
        line = f"{command}"
        if description:
            line = f"{command:<25} - {description}"
            
        # Calculate padding and print centered
        padding = max(0, (terminal_width - len(
            line.replace('\033[95m', '').replace('\033[94m', '').replace('\033[96m', '')
                .replace('\033[92m', '').replace('\033[93m', '').replace('\033[91m', '')
                .replace('\033[0m', '').replace('\033[1m', '')
        )) // 2)
        
        print(' ' * padding + line)
    
    input()

 

def main():
    """Main function to start the game."""
    # Set up console first
    if sys.platform.startswith('win'):
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleCP(65001)
        kernel32.SetConsoleOutputCP(65001)
    
    # Set stdout to handle UTF-8
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    
    # Main game loop
    while True:
        choice = show_menu()
        
        if choice == '1':  # New Game
            try:
                from game import GameController
                game = GameController()
                game.start_game()
            except Exception as e:
                print(f"\n{Colors.RED}An error occurred: {e}{Colors.ENDC}")
                input("Press Enter to continue...")
                
        elif choice == '2':  # How to Play
            show_instructions()
            
        elif choice == '3':  # Quit
            clear_screen()
            print(f"\n{Colors.YELLOW}▀█▀ █░█ ▄▀█ █▄░█ █▄▀ █▀   █▀▀ █▀█ █▀█   █▀█ █░░ ▄▀█ █▄█ █ █▄░█ █▀▀ █\n░█░ █▀█ █▀█ █░▀█ █░█ ▄█   █▀░ █▄█ █▀▄   █▀▀ █▄▄ █▀█ ░█░ █ █░▀█ █▄█ ▄{Colors.ENDC}\n")
            break

if __name__ == "__main__":
    main()
