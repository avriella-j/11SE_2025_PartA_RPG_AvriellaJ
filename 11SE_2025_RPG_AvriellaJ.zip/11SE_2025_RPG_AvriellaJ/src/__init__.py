"""
RPG Game Package

This is the main package for the RPG game.
"""

__version__ = "0.1.0"
