# Space Station Repair Mission

A text-based adventure game built with Python using object-oriented programming principles. Navigate through the space station, solve puzzles, and complete your mission to save the station from a critical power failure!

## 🚀 Game Overview
You are a technician aboard the deep space station Epsilon-7. The station's power core is failing, and you need to retrieve the energy crystal from the docking bay to stabilize it. However, a damaged maintenance droid is blocking the way. Find the diagnostic tool to repair it and complete your mission!

## ✨ Features
- Immersive text-based adventure with multiple locations to explore
- Object-oriented design following PEP-8 standards
- Intuitive command system with natural language processing
- Score tracking and hazard system with visual indicators
- Color-coded UI for better readability and feedback
- Enhanced win message with visual styling
- Puzzle-solving gameplay with item collection and usage
- Clear win condition with detailed feedback

## 🛠️ Installation
1. Ensure you have Python 3.8 or higher installed
2. Download or clone the repository:
   ```bash
   git clone https://github.com/yourusername/space-station-repair.git
   ```
3. Navigate to the project directory
4. Run the game:
   ```bash
   python -m src.main
   ```

## 🎮 How to Play
### 🎨 Color Coding
- **Cyan**: Room borders and UI elements
- **Green**: Success messages and important items
- **Yellow**: Warnings and important information
- **Red**: Errors and hazard indicators
- **Purple**: Decorative elements and highlights

### Basic Commands
- `north/south/east/west` or `n/s/e/w` - Move in the specified direction
- `look` or `look around` - View current location description
- `pick up tool` - Pick up the diagnostic tool
- `use tool` - Use the diagnostic tool on a droid
- `pick up crystal` - Pick up the energy crystal
- `inventory` or `i` - Check your inventory
- `status` - Show your current score and hazard count
- `win` - Attempt to complete the mission (only works in Docking Bay with crystal)
- `help` - Show available commands
- `quit` - Exit the game

### 🎯 Game Objective
1. Explore the space station to find the diagnostic tool
2. Use the tool to repair the damaged maintenance droid blocking the corridor
3. Retrieve the energy crystal from the Docking Bay
4. Return to the Docking Bay with the crystal and type 'win' to complete the mission

## 📊 Scoring System
- **+10 points** for picking up the diagnostic tool
- **+20 points** for repairing the maintenance droid
- **+50 points** for retrieving the energy crystal
- **-1 point** for each hazard encountered

## 📂 Project Structure
```
src/
├── game/
│   ├── __init__.py
│   ├── game_controller.py  # Main game logic and flow
│   ├── game_objects.py     # Core game classes
│   └── items.py            # Item definitions
└── main.py                 # Entry point
```

## 📝 Documentation
- [Product Requirements (PRD)](docs/PRD.md)
- [Changelog](docs/CHANGELOG.md)

## 🤝 Contributing
Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
